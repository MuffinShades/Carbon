#pragma once
#include <iostream>
#include "window.hpp"
#include "Shader.hpp"
#include "mesh.hpp"
#include "vertex.hpp"
#include "../bitmap.hpp"

#define _CARBONGL_SHADOW_SPECIAL_VAL 0xfb01

struct __mu_glVInf {
    size_t off = 0, sz = 0, p_sz = 0;
};

extern inline __mu_glVInf __gen_glvinf(size_t sz, size_t off, size_t p_sz) {
    return {
        .off = off,
        .sz = sz,
        .p_sz = p_sz
    };
}

#define vertexClassPart(v, part) \
    __gen_glvinf(sizeof(v), offsetof(v, part), sizeof(v::part))

#define vertexFloatBufSelect(v_buf, i, part) \
    v_buf[((sizeof(v_buf) / sizeof(f32)) * (i))]

struct OutputDevice {
    void *device = nullptr;
    enum {
        DefaultOutputDevice,
        FrameBuffer,
        Unknown
    } type;
};

class FrameBuffer {
public:
    enum fb_type {
        Texture,
        Depth,
        Render,
        Unknown
    };
protected:
    u32 handle = 0, texHandle = 0, rbo = 0;
    fb_type ty = FrameBuffer::Texture;

    void bind();
    void delete_tex();
    
    void texAttach(u32 w, u32 h);
    void depthStencilAttach(u32 w, u32 h);
    void depthAttach(u32 w, u32 h);

    OutputDevice od;

    u64 specialVal = 0; //reserved for derived classes
public:
    u32 w = 0, h = 0;

    FrameBuffer() {}
    FrameBuffer(fb_type ty, u32 w, u32 h);
    u32 getHandle() {
        return this->handle;
    }
    void free() {
        if (this->handle != 0)
            glDeleteFramebuffers(1, &this->handle); 
    }
    Bitmap extractBitmap();
    void extractToBitmap(Bitmap *map);
    friend class graphics;

    OutputDevice *device() {
        this->od.device = (void*) this;
        this->od.type = OutputDevice::FrameBuffer;

        return &this->od;
    }

    u32 getTextureHandle() {return this->texHandle;}
};

struct graphicsState {
    u32 vao, vbo, ibo;
    bool vbo_alloc = false;
    Shader *s = nullptr;
    size_t nv = 0;
    void *vmem = nullptr, *vstore = nullptr;
    enum class __gs_fmt {
        _null,
        _static,
        _dynamic
    } g_fmt = __gs_fmt::_null;
    struct {
        size_t v_obj_sz = 0;
    } __int_prop;
};

class graphics {
private:
    graphicsState interalState;
    graphicsState *cur_state = nullptr;
    Window *win = nullptr;
    mat4 proj_matrix;
    size_t _c_vert = 0, mush_offset = 0;

    void vmem_alloc(size_t sz);
    void vmem_clear();

    void bind_vao() {
        if (!this->cur_state)
            return;

        if (this->cur_state->vao != 0)
            glBindVertexArray(this->cur_state->vao);
        else
           std::cout << "Failed to bind to vao!" << std::endl;
    }

    Shader *s = nullptr, *def_shader = nullptr;

    enum ReserveState {
        None,
        Mush,
        MeshBind,
        VertexDef
    } rs_state = ReserveState::None;

    //flags
    bool using_foreign_gs = false;
    bool using_indicies = false;
    bool shader_bound = false;
    bool using_default_device = true;

    void shader_bind();
    void shader_unbind();

    f32 winW, winH;

public:
    enum class StockRenderType {
        Line
        
    };  

    graphics(Window *w) {
        if (w != nullptr)
            this->win = w;
        else
            return;

        this->winW = this->win->w;
        this->winH = this->win->h;
    }

    graphics() {

    }

    void Load();
    void WinResize(const size_t w, const size_t h);
    void render_begin(bool clear = true);
    void render_flush();
    void render_noflush();
    void render_no_geo_update();
    void render_bind();
    void flush();
    void mush_begin();
    void mush_render(Mesh *m);
    void mush_end();
    void mesh_single_bind(Mesh* m);
    void mesh_unbind();
    void setCurrentShader(Shader *s);
    void bindMeshToVbo(Mesh *m);

    void vertexStructureDefineBegin(size_t vObjSz);
    void defineVertexPart(i32 n, __mu_glVInf inf);
    void defineIntegerVertexPart(i32 n, __mu_glVInf inf);
    void vertexStructureDefineEnd();

    void enableIndicies();
    void disableIndicies();

    void set_indicies(void *i, size_t n);
    void push_indicies(void *i, size_t n);
    void clear_indicies();

    void push_verts(void *v, size_t n);
    void set_verts(void *v, size_t n);
    void clear_verts();
    size_t vert_space();

    //graphics states
    void iniStaticGraphicsState();
    void iniDynamicGraphicsState(size_t nBufferVerts);
    bool useGraphicsState(graphicsState *gs);
    void useDefaultGraphicsState();

    //frame buffers
    void setOutputDevice(OutputDevice* device);
    void restoreDefaultOutputDevice();

    Shader* getCurrentShader();
    //void DrawImage();
    //void FillRect(float x, float y, float w, float h);
    void free_state();
    const size_t getEstimatedMemoryUsage();
};
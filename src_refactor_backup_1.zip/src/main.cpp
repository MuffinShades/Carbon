#include <iostream>
#include "msutil.hpp"
#include "game/game_main.hpp"
#include "png.hpp"
#include "bitmap.hpp"
#include "ttf.hpp"
#include "ttf_render.hpp"
#include "polynom.hpp"
#include "logger.hpp"
#include "gl/window.hpp"
#include "gl/geometry/rect.hpp"

f32 __cube_root_32(f32 v) {
    const f32 m = -(2.0f * (i32) (v < 0) - 1.0f);
    return m * powf(m * v, 1.0f/3.0f);
}

#include <chrono>

FrameBuffer fb;

i32 main() {
    //if (game_main())
    //    std::cout << "failed to execute game!" << std::endl;

    /*png_image p = PngParse::Decode(ContentSrc::FromFile("C:\\Users\\chris\\OneDrive\\Desktop\\minecraftskin - Copy.png"));
    Bitmap bmp = Bitmap::CreateBitmap(p.inf.width, p.inf.height);
    bmp.data = p.data;
    
    BitmapParse::WriteToFile("C:\\Users\\chris\\OneDrive\\Desktop\\png_test_decode.bmp", &bmp);
    
    delete[] p.data;*/

    //TODO: % top left contour has wrong ordering / winding!!!
    //TODO: times new roman capital theta (0x398) has incorrect contour winding
    //TODO: error correction
    //TODO: fix the bitmap rendering
    //TODO: processing too many edges (0x6dd)
    /*Glyph g = ttfParse::ReadTTFGlyph("../../test/arial.ttf", 'Q');
    Bitmap sdf, g_bmp, outline_bmp;
    //ttfRender::RenderGlyphOutlineToBitmap(g, &outline_bmp, sdf_width_dim(64));
    //ttfRender::RenderGlyphMSDFToBitMap(g, &sdf, sdf_width_dim(128));
    //ttfRender::RenderMSDFToBitmap(&sdf, &g_bmp, sdf_width_dim(256));

    using std::chrono::high_resolution_clock;
    using std::chrono::duration_cast;
    using std::chrono::duration;
    using std::chrono::milliseconds;

    auto t1 = high_resolution_clock::now();
    

    //TODO: fix weird pixels when writing bitmap (bytestream may be the issue)
    //TODO: check bytestream for writing. Especially writeUint24 --> odd number of bytes
    //TODO: also check bitstream
    //TODO: fix blur in the glyphs
    //TODO: change bitmap to use WriteUInt24 after you fix the aformentioned issue

    FontInst font = ttfRender::GenerateUnicodeMSDFSubset("../../test/times.ttf", UnicodeRange::SimpleAlphabet, sdf_width_dim(32));

    auto t2 = high_resolution_clock::now();
    duration<double, std::milli> ms_double = t2 - t1;
    std::cout << "Took " << ms_double.count() << "ms to generete all glyphs" << std::endl;

    BitmapParse::WriteToFile("../../test/sheet_o_glyphs.bmp", &font.sheet);

    Glyph lower_c = ttfParse::ReadTTFGlyph("../../test/segoeui.ttf", 'c');
    Bitmap b_c;
    
    ttfRender::RenderGlyphMSDFToBitMap(lower_c, &b_c, sdf_width_dim(32));

    Logger L;

    L.DrawBitMapClip(64, 64, b_c);*/

    //BitmapParse::WriteToFile("../../test/glyph_outline.bmp", &outline_bmp);
    //BitmapParse::WriteToFile("../../test/notaapple.bmp", &g_bmp);
    //BitmapParse::WriteToFile("../../test/alsonotaapple.bmp", &sdf);

    struct _vert {
        f32 pos[3];
    };

    Window::winIni();
    Window win = Window("", 500, 500, false);

    /*graphics g = graphics(&win);

    g.Load();

    g.vertexStructureDefineBegin(sizeof(_vert));
    g.defineVertexPart(0, vertexClassPart(_vert, pos));
    g.vertexStructureDefineEnd();

    Shader s = Shader::LoadShaderFromFile("../src/fb_test_vert.glsl", "../src/fb_test_frag.glsl");
    g.setCurrentShader(&s);

    fb = FrameBuffer(FrameBuffer::Texture, 500, 500);
    //g.setOutputDevice(fb.device());

    //g.render_begin();

    f32 test_verts[] = RECT_VERTS(0.0f,0.0f,.5f,.5f, 0.0f);

    glClearColor(1.0f, 1.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    g.render_begin();
    g.push_verts(test_verts, sizeof(test_verts) / sizeof(_vert));
    g.render_flush();

    //g.push_verts(test_verts, sizeof(test_verts));
    //g.render_flush();

    Bitmap bmp =  fb.extractBitmap();

    std::cout << "writing bmp..." << std::endl;

    BitmapParse::WriteToFile("../../test/framebufferwrite.bmp", &bmp);*/

    //FontInst font = ttfRender::GenerateUnicodeMSDFSubset("../../test/times.ttf", UnicodeRange::SimpleAlphabet, sdf_width_dim(32), true);

    //std::cout << "Bitmap Dim: " << font.sheet.header.w << " " << font.sheet.header.h << std::endl;
    //std::cout << "Size: " << font.sheet.header.fSz << std::endl;

    //BitmapParse::WriteToFile("../../test/framebufferwrite.bmp", &font.sheet);

    //Logger L;

    //L.DrawBitMapClip(64, 64, font.sheet);

    //Glyph testGlyph = ttfParse::ReadTTFGlyph("../../test/times.ttf", 'G');

    //Bitmap b_c;
    
    //ttfRender::RenderGlyphMSDFToBitMap(testGlyph, &b_c, sdf_width_dim(256));

    //BitmapParse::WriteToFile("../../test/gpu_accel_dbg.bmp", &b_c);

    //Bitmap::Free(&b_c);

    //MsdfGpuContext *ctx = nullptr;

    FontInst f = ttfRender::GenerateUnicodeMSDFSubset("../../test/times.ttf", UnicodeRange::SimpleAlphabet, sdf_width_dim(64), true);

    u32 tex_hand = f.fb.getTextureHandle();

    graphics g = graphics(&win);

    g.Load();
    g.vertexStructureDefineBegin(sizeof(_vert));
    g.defineVertexPart(0, vertexClassPart(_vert, pos));
    g.vertexStructureDefineEnd();

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex_hand);

    glBindFramebuffer(GL_FRAMEBUFFER,0);

    Shader s = Shader::LoadShaderFromFile("../../src/fb_test_vert.glsl", "../../src/fb_test_frag.glsl");
    g.setCurrentShader(&s);

    BitmapParse::WriteToFile("../../test/gpu_accel_dbg.bmp", &f.sheet);

    f32 rv[] = RECT_VERTS(-1.0f, -1.0f, 2.0f, 2.0f, 0.0f);

    while (win.isRunning()) {
        //ttfRender::_msdfRenderDebug(testGlyph, &ctx);
        g.render_begin();
        g.push_verts(rv, sizeof(rv));
        g.render_flush();

        win.Update();
    }

    //BitmapParse::WriteToFile("../../test/gpu_accel_dbg.bmp", &f.sheet);

    Bitmap::Free(&f.sheet);

    //delete[] sdf.data, g_bmp.data;

    return 0;
}